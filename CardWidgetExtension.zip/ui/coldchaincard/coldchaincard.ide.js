TW.IDE.Widgets.coldchaincard = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/CardWidgetExtension/ui/coldchaincard/default_widget_icon.ide.png'";
	};

//Code for setting the properties for the widegt
	
	
	
	
	this.widgetProperties = function () {    
		return {
			'name': 'coldchaincard',
			'description': '',
			'category': ['Common'],
		
			'properties': {
	           
			                  
			     'Label': {
		   			        'baseType': "STRING",
					        'displayString': '',
					        'defaultValue': 'Label',
					        'isBindingTarget': false
					        
					      
			               },     
	          
	                     
	            'DataField': {
	 	                    'description': 'Data source',
	 	                    'isBindingTarget': true,
	 	                    'baseType': 'NUMBER',
	 	                    'defaultValue': '0',
	 	                    'warnIfNotBoundAsTarget': true
	 	                   
	 	                    },
        
	 	   
	 	    
	 	     'CustomClass': {

	 		                  'description': 'Custom Class',
	 		                  'baseType': 'STRING',
	 		                  'isLocalizable': false,
	 		                  'isBindingSource': true,
	 		                  'isBindingTarget': true

	 		              },
	 		          		
                  'Width': {
			                    'description': 'Widget width',
			                    'default value': 146,
			                    'isEditable':true
			                    
			                },
			                
                'Height': {
                           'description': 'Widget height',
                           'default value': 145,
                           'isEditable':true
                           
                         }
     }
   };
  };

//Function to be Called after any property is updated
  
  this.afterSetProperty = function (name, value) {
   var thisWidget = this;
   var refreshHtml = false;
    switch (name) {
	  case 'Style':
   
   case 'Label':
		thisWidget.jqElement.find('.label').text(value);
		break;		
 
  
	 case 'Alignment':
		refreshHtml = true;
		break;
	 default:
		break;
}
return refreshHtml;
};

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).

		
		var html = '';
	    html += '<div class="widget-content widget-statuscard" style=" height: 145px;width: 146px;border-radius:20px;box-shadow:0px 0px 6px 0px #ccc;float: left;margin: 10px 10px 0px 10px;background: #1B2A47;display: flex;border: 1px solid ; cursor: pointer;font-family: Arial, Helvetica, sans-serif;">'
	    	+'<span class="label" style=" height: 16px;width: 140px;border-radius: 0px;float: left;margin: 20px 10px 130px 10px;background: #1B2A47;display: flex;cursor: pointer;font-size:16px;color:#ffffff; font-family: Arial, Helvetica, sans-serif;">' + this.getProperty('Label') + 
	         '</span>' +'<span class="data" style=" height: 16px;width: 50px;border-radius: 0px;float: left;margin: 74px 10px 0px 5px;background: #1B2A47;display: flex; cursor: pointer;font-size:20px;color:#ffffff;font-family: Arial, Helvetica, sans-serif;">' + this.getProperty('DataField') + '</span>' + 
	     +'</div>';
	    return html;
		};  
			
	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		var valueElem1 = this.jqElement.find('.data');
		valueElem1.text(this.getProperty('DataField'));
		
		
	    var valueElem2 = this.jqElement.find('.label');
		valueElem2.text(this.getProperty('Label'));
		
		
				
	};
	

};